﻿using System;
using System.Text;
using Crestron.SimplSharp;                         				// For Basic SIMPL# Classes
using Crestron.SimplSharp.Net.Http;

namespace PurpleAir
{
    #region Delegates
    public delegate void DelegateFn(short Temperature_F, short Humidity, short Dewpoint_F, short Pressure,
        short PM25_Sensor_1_AQI, short PM25_Sensor_2_AQI, short PM25_Avg_1_and_2_AQI,
        short PM25_Color_RGB_Red_Sensor_1, short PM25_Color_RGB_Green_Sensor_1, short PM25_Color_RGB_Blue_Sensor_1,
        short PM2_5_Color_RGB_Red_Sensor_2, short PM2_5_Color_RGB_Green_Sensor_2, short PM2_5_Color_RGB_Blue_Sensor_2,
        short PM_1_dot_0_cf_Sensor_1, short PM_2_dot_5_cf_Sensor_1, short PM_10_cf_Sensor_1, short PM_1_dot_0_atm_Sensor_1, 
        short PM_2_dot_5_atm_Sensor_1, short PM_10_atm_Sensor_1, short PM_1_dot_0_cf_Sensor_2, short PM_2_dot_5_cf_Sensor_2, 
        short PM_10_cf_Sensor_2, short PM_1_dot_0_atm_Sensor_2, short PM_2_dot_5_atm_Sensor_2, short PM_10_atm_Sensor_2,
        short Latitude_Valid, short Longitude_Valid, short Place_Valid, short Temperature_F_Valid, short Humidity_Valid,
        short Dewpoint_F_Valid, short Pressure_Valid, short PM25_AQI_Sensor_1_Valid, short PM25_AQI_Sensor_2_Valid,
        short PM25_AQI_Color_Sensor_1_Valid, short PM25_AQI_Color_Sensor_2_Valid, short PM25_AQI_Color_Avg_1_and_2_Valid, short PM_1_dot_0_cf_Sensor_1_Valid,
        short PM_2_dot_5_cf_Sensor_1_Valid, short PM_10_cf_Sensor_1_Valid, short PM_1_dot_0_atm_Sensor_1_Valid, short PM_2_dot_5_atm_Sensor_1_Valid,
        short PM_10_atm_Sensor_1_Valid, short PM_1_dot_0_cf_Sensor_2_Valid, short PM_2_dot_5_cf_Sensor_2_Valid, short PM_10_cf_Sensor_2_Valid,
        short PM_1_dot_0_atm_Sensor_2_Valid, short PM_2_dot_5_atm_Sensor_2_Valid, short PM_10_atm_Sensor_2_Valid, SimplSharpString Latitude_Display_String,
        SimplSharpString Longitude_Display_String, SimplSharpString Place_Display_String, SimplSharpString Temperature_F_Display_String,
        SimplSharpString Humidity_Display_String, SimplSharpString Dewpoint_F_Display_String, SimplSharpString Pressure_Display_String,
        SimplSharpString PM25_AQI_Sensor_1_Display_String, SimplSharpString PM25_AQI_Sensor_2_Display_String, 
        SimplSharpString PM25_AQI_Avg_1_and_2_Display_String, SimplSharpString PM_1_dot_0_cf_Sensor_1_Display_String, 
        SimplSharpString PM_2_dot_5_cf_Sensor_1_Display_String, SimplSharpString PM_10_cf_Sensor_1_Display_String, 
        SimplSharpString PM_1_dot_0_atm_Sensor_1_Display_String, SimplSharpString PM_2_dot_5_atm_Sensor_1_Display_String,
        SimplSharpString PM_10_atm_Sensor_1_Display_String, SimplSharpString PM_1_dot_0_cf_Sensor_2_Display_String,
        SimplSharpString PM_2_dot_5_cf_Sensor_2_Display_String, SimplSharpString PM_10_cf_Sensor_2_Display_String,
        SimplSharpString PM_1_dot_0_atm_Sensor_2_Display_String, SimplSharpString PM_2_dot_5_atm_Sensor_2_Display_String,
        SimplSharpString PM_10_atm_Sensor_2_Display_String, SimplSharpString Collection_DateTime_Display_String);
    #endregion

    public class PurpleAir_Integration
    {
        public DelegateFn callback_fn { get; set; }

        //****************************************************************************************
        // 
        //  PurpleAir_Integration	-	Constructor
        // 
        //****************************************************************************************
        public PurpleAir_Integration()
        {
        }

        #region Declarations

        //NOTE - CF Readings use an estimated mass concentration level for 
        //       indoor particles and atm use an estimated mass concentration 
        //       for outdoor particles

        private long Polling_Interval_Msec;						                // time between polling of PurpleAir Sensor in msec
        private CTimer cTimer = null;											//timer thread for collecting data 

        private string IP_Address;                                              //IP Address for collecting data from sensor
        private short Sensor_Count;                                             //Number of sensors installed in the monitor

        private string Latitude_S;                                              //parsed latitude
        private string Longitude_S;                                             //parsed longitude
        private string Place_S;                                                 //parsed place (inside/outside)
        private string Temperature_F_S;                                         //parsed temperature in fareinheit
        private string Humidity_S;                                              //parsed humidity
        private string Dewpoint_F_S;                                            //parsed dewpoint in fareinheit
        private string Pressure_S;                                              //parsed barometric pressure in mb
        private string PM25_AQI_Sensor_1_S;                                     //air quality index
        private string PM25_AQI_Sensor_2_S;                                     //air quality index
        private string PM25_AQI_Color_Sensor_1_S;                               //air quality index rgb color
        private string PM25_AQI_Color_Sensor_2_S;                               //air quality index rgb color
        private string PM_1_dot_0_cf_Sensor_1_S;                                //PM 1.0 particle concentration readings from sensor 1 in ug/m^3
        private string PM_2_dot_5_cf_Sensor_1_S;                                //PM 2.5 particle concentration readingsfrom sensor 1 in ug/m^3 
        private string PM_10_cf_Sensor_1_S;                                     //PM 10 particle concentration readings from sensor 1 in ug/m^3 
        private string PM_1_dot_0_atm_Sensor_1_S;                               //PM 1.0 particle concentration readings from sensor 1 in ug/m^3 
        private string PM_2_dot_5_atm_Sensor_1_S;                               //PM 2.5 particle concentration readings from sensor 1 in ug/m^3 
        private string PM_10_atm_Sensor_1_S;                                    //PM 10 particle concentration readings from sensor 1 in ug/m^3 
        private string PM_1_dot_0_cf_Sensor_2_S;                                //PM 1.0 particle concentration readings from sensor 2 in ug/m^3 
        private string PM_2_dot_5_cf_Sensor_2_S;                                //PM 2.5 particle concentration readings from sensor 2 in ug/m^3 
        private string PM_10_cf_Sensor_2_S;                                     //PM 10 particle concentration readings from sensor 2 in ug/m^3 
        private string PM_1_dot_0_atm_Sensor_2_S;                               //PM 1.0 particle concentration readings from sensor 2 in ug/m^3 
        private string PM_2_dot_5_atm_Sensor_2_S;                               //PM 2.5 particle concentration readings from sensor 2 in ug/m^3 
        private string PM_10_atm_Sensor_2_S;                                    //PM 10 particle concentration readings from sensor 2 in ug/m^3 

        private short Latitude_Valid;                                           //1 if data element parsed, otherwise 0
        private short Longitude_Valid;                                          //1 if data element parsed, otherwise 0
        private short Place_Valid;                                              //1 if data element parsed, otherwise 0
        private short Temperature_F_Valid;                                      //1 if data element parsed, otherwise 0
        private short Humidity_Valid;                                           //1 if data element parsed, otherwise 0
        private short Dewpoint_F_Valid;                                         //1 if data element parsed, otherwise 0
        private short Pressure_Valid;                                           //1 if data element parsed, otherwise 0
        private short PM25_AQI_Sensor_1_Valid;                                  //1 if data element parsed, otherwise 0
        private short PM25_AQI_Sensor_2_Valid;                                  //1 if data element parsed, otherwise 0
        private short PM25_AQI_Avg_1_and_2_Valid;                               //1 if data element parsed, otherwise 0
        private short PM25_AQI_Color_Sensor_1_Valid;                            //1 if data element parsed, otherwise 0
        private short PM25_AQI_Color_Sensor_2_Valid;                            //1 if data element parsed, otherwise 0
        private short PM_1_dot_0_cf_Sensor_1_Valid;                             //1 if data element parsed, otherwise 0
        private short PM_2_dot_5_cf_Sensor_1_Valid;                             //1 if data element parsed, otherwise 0
        private short PM_10_cf_Sensor_1_Valid;                                  //1 if data element parsed, otherwise 0
        private short PM_1_dot_0_atm_Sensor_1_Valid;                            //1 if data element parsed, otherwise 0
        private short PM_2_dot_5_atm_Sensor_1_Valid;                            //1 if data element parsed, otherwise 0
        private short PM_10_atm_Sensor_1_Valid;                                 //1 if data element parsed, otherwise 0
        private short PM_1_dot_0_cf_Sensor_2_Valid;                             //1 if data element parsed, otherwise 0
        private short PM_2_dot_5_cf_Sensor_2_Valid;                             //1 if data element parsed, otherwise 0
        private short PM_10_cf_Sensor_2_Valid;                                  //1 if data element parsed, otherwise 0
        private short PM_1_dot_0_atm_Sensor_2_Valid;                            //1 if data element parsed, otherwise 0
        private short PM_2_dot_5_atm_Sensor_2_Valid;                            //1 if data element parsed, otherwise 0
        private short PM_10_atm_Sensor_2_Valid;                                 //1 if data element parsed, otherwise 0

        private short Temperature_F;                                            //numerical value of json data element
        private short Humidity;                                                 //numerical value of json data element
        private short Dewpoint_F;                                               //numerical value of json data element
        private short Pressure;                                                 //numerical value of json data element
        private short PM25_AQI_Sensor_1;                                        //numerical value of json data element
        private short PM25_AQI_Sensor_2;                                        //numerical value of json data element
        private short PM25_AQI_Avg_1_and_2;                                     //numerical value of json data element
        private short PM25_Color_RGB_Red_Sensor_1;                              //PM2.5 RGB Red Value
        private short PM25_Color_RGB_Green_Sensor_1;                            //PM2.5 RGB Green Value
        private short PM25_Color_RGB_Blue_Sensor_1;                             //PM2.5 RGB Blue Value
        private short PM25_Color_RGB_Red_Sensor_2;                              //PM2.5 RGB Red Value
        private short PM25_Color_RGB_Green_Sensor_2;                            //PM2.5 RGB Green Value
        private short PM25_Color_RGB_Blue_Sensor_2;                             //PM2.5 RGB Blue Value
        private short PM_1_dot_0_cf_Sensor_1;                                   //Sensor data multiplied x 100
        private short PM_2_dot_5_cf_Sensor_1;                                   //Sensor data multiplied x 100
        private short PM_10_cf_Sensor_1;                                        //Sensor data multiplied x 100
        private short PM_1_dot_0_atm_Sensor_1;                                  //Sensor data multiplied x 100
        private short PM_2_dot_5_atm_Sensor_1;                                  //Sensor data multiplied x 100
        private short PM_10_atm_Sensor_1;                                       //Sensor data multiplied x 100
        private short PM_1_dot_0_cf_Sensor_2;                                   //Sensor data multiplied x 100
        private short PM_2_dot_5_cf_Sensor_2;                                   //Sensor data multiplied x 100
        private short PM_10_cf_Sensor_2;                                        //Sensor data multiplied x 100
        private short PM_1_dot_0_atm_Sensor_2;                                  //Sensor data multiplied x 100
        private short PM_2_dot_5_atm_Sensor_2;                                  //Sensor data multiplied x 100
        private short PM_10_atm_Sensor_2;                                       //Sensor data multiplied x 100

        private string Latitude_Display_String;                                 //Formatted string for Crestron Display
        private string Longitude_Display_String;                                //Formatted string for Crestron Display
        private string Place_Display_String;                                    //Formatted string for Crestron Display
        private string Temperature_F_Display_String;                            //Formatted string for Crestron Display
        private string Humidity_Display_String;                                 //Formatted string for Crestron Display
        private string Dewpoint_F_Display_String;                               //Formatted string for Crestron Display
        private string Pressure_Display_String;                                 //Formatted string for Crestron Display
        private string PM25_AQI_Sensor_1_Display_String;                        //Formatted string for Crestron Display
        private string PM25_AQI_Sensor_2_Display_String;                        //Formatted string for Crestron Display
        private string PM25_AQI_Avg_1_and_2_Display_String;                     //Formatted string for Crestron Display
        private string PM_1_dot_0_cf_Sensor_1_Display_String;                   //Formatted string for Crestron Display
        private string PM_2_dot_5_cf_Sensor_1_Display_String;                   //Formatted string for Crestron Display
        private string PM_10_cf_Sensor_1_Display_String;                        //Formatted string for Crestron Display
        private string PM_1_dot_0_atm_Sensor_1_Display_String;                  //Formatted string for Crestron Display
        private string PM_2_dot_5_atm_Sensor_1_Display_String;                  //Formatted string for Crestron Display
        private string PM_10_atm_Sensor_1_Display_String;                       //Formatted string for Crestron Display
        private string PM_1_dot_0_cf_Sensor_2_Display_String;                   //Formatted string for Crestron Display
        private string PM_2_dot_5_cf_Sensor_2_Display_String;                   //Formatted string for Crestron Display
        private string PM_10_cf_Sensor_2_Display_String;                        //Formatted string for Crestron Display
        private string PM_1_dot_0_atm_Sensor_2_Display_String;                  //Formatted string for Crestron Display
        private string PM_2_dot_5_atm_Sensor_2_Display_String;                  //Formatted string for Crestron Display
        private string PM_10_atm_Sensor_2_Display_String;                       //Formatted string for Crestron Display
        private string Collection_DateTime_Display_String;                      //data and time data collected
        #endregion
        //****************************************************************************************
        // 
        //  Initialization	-	
        // 
        //****************************************************************************************
        public void Initialization(string IP_Address, string Polling_Interval_Seconds, short Sensor_Count)
        {
            #region Check for proper configuration

            if (IP_Address == "")
            {
                CrestronConsole.PrintLine("PurpleAir-ERROR: Missing IP Address for PurpleAir Initialization");
                Crestron.SimplSharp.ErrorLog.Error("PurpleAir-ERROR: Missing IP Address for PurpleAir Initialization");
                return;
            }

            if (Polling_Interval_Seconds == "")
            {
                CrestronConsole.PrintLine("PurpleAir-ERROR: Missing Polling Interval for PurpleAir Initialization");
                Crestron.SimplSharp.ErrorLog.Error("PurpleAir-ERROR: Missing Polling Interval for PurpleAir Initialization");
                return;
            }

            if ((Sensor_Count < 1) || (Sensor_Count > 2)) 
            {
                CrestronConsole.PrintLine("PurpleAir-ERROR: Invalid Sensor Count for PurpleAir Initialization");
                Crestron.SimplSharp.ErrorLog.Error("PurpleAir-ERROR: Invalid Sensor Count for PurpleAir Initialization");
                return;
            }

            Polling_Interval_Msec = long.Parse(Polling_Interval_Seconds) * 1000;
            if (Polling_Interval_Msec == 0)
            {
                CrestronConsole.PrintLine("PurpleAir-ERROR: Polling interval equal to zero");
                Crestron.SimplSharp.ErrorLog.Error("PurpleAir-ERROR: Polling interval equal to zero");
                return;
            }

            if (callback_fn == null)
            {
                CrestronConsole.PrintLine("PurpleAir-ERROR: Callback Function is NULL");
                Crestron.SimplSharp.ErrorLog.Error("PurpleAir-ERROR: Callback Function is NULL");
                return;
            }
            #endregion

            #region Save Parameters to globals
            this.IP_Address = IP_Address;
            this.Sensor_Count = Sensor_Count;
            #endregion

            #region Start Timer to Get Data at Interval Specified
            if (cTimer == null)
            {
                try
                {
                    CTimerCallbackFunction cTimerCallbackFunction = new CTimerCallbackFunction(Main_Timer_Thread);
                    cTimer = new CTimer(Main_Timer_Thread, null, 0, Polling_Interval_Msec);
                }
                catch (Exception e)
                {
                    CrestronConsole.PrintLine(string.Format("PurpleAir-Can't create timer thread: " + e + "\n"));
                    Crestron.SimplSharp.ErrorLog.Error(string.Format("PurpleAir-Can't create timer thread: " + e + "\n"));
                    return;
                }
            }
            else
            {
                try
                {
                    //restart timer that was previously stopped
                    cTimer.Reset(0, Polling_Interval_Msec);
                }
                catch (Exception e)
                {
                    CrestronConsole.PrintLine(string.Format("PurpleAir-Can't restart timer thread: " + e + "\n"));
                    Crestron.SimplSharp.ErrorLog.Error(string.Format("PurpleAir-Can't restart timer thread: " + e + "\n"));
                    return;
                }
            }

            #endregion
        }
        //****************************************************************************************
        // 
        //  Main_Timer_Thread	-	
        // 
        //****************************************************************************************
        private void Main_Timer_Thread(Object unused)
        {
            string url, s;
            HttpClientResponse httpResponse;

            #region get PurpleAir data
            try
            {
                url = "http://" + IP_Address + "/json?live=TRUE";
                httpResponse = Send_Message_Get(url);
                s = httpResponse.ContentString;

                Parse_Data(s);

                //Send Data Back to Simpl
                callback_fn(Temperature_F, Humidity, Dewpoint_F, Pressure, PM25_AQI_Sensor_1, PM25_AQI_Sensor_2, PM25_AQI_Avg_1_and_2,
                    PM25_Color_RGB_Red_Sensor_1, PM25_Color_RGB_Green_Sensor_1, PM25_Color_RGB_Blue_Sensor_1,
                    PM25_Color_RGB_Red_Sensor_2, PM25_Color_RGB_Green_Sensor_2, PM25_Color_RGB_Blue_Sensor_2,
                    PM_1_dot_0_cf_Sensor_1, PM_2_dot_5_cf_Sensor_1, PM_10_cf_Sensor_1, PM_1_dot_0_atm_Sensor_1, PM_2_dot_5_atm_Sensor_1, 
                    PM_10_atm_Sensor_1, PM_1_dot_0_cf_Sensor_2, PM_2_dot_5_cf_Sensor_2, PM_10_cf_Sensor_2, PM_1_dot_0_atm_Sensor_2,
                    PM_2_dot_5_atm_Sensor_2, PM_10_atm_Sensor_2, Latitude_Valid, Longitude_Valid, Place_Valid, Temperature_F_Valid,
                    Humidity_Valid, Dewpoint_F_Valid, Pressure_Valid, PM25_AQI_Sensor_1_Valid, PM25_AQI_Sensor_2_Valid, PM25_AQI_Avg_1_and_2_Valid, 
                    PM25_AQI_Color_Sensor_1_Valid, PM25_AQI_Color_Sensor_2_Valid, PM_1_dot_0_cf_Sensor_1_Valid,
                    PM_2_dot_5_cf_Sensor_1_Valid, PM_10_cf_Sensor_1_Valid, PM_1_dot_0_atm_Sensor_1_Valid, PM_2_dot_5_atm_Sensor_1_Valid,
                    PM_10_atm_Sensor_1_Valid, PM_1_dot_0_cf_Sensor_2_Valid, PM_2_dot_5_cf_Sensor_2_Valid, PM_10_cf_Sensor_2_Valid,
                    PM_1_dot_0_atm_Sensor_2_Valid, PM_2_dot_5_atm_Sensor_2_Valid, PM_10_atm_Sensor_2_Valid,  Latitude_Display_String,
                    Longitude_Display_String,  Place_Display_String,  Temperature_F_Display_String, Humidity_Display_String,
                    Dewpoint_F_Display_String, Pressure_Display_String, PM25_AQI_Sensor_1_Display_String, PM25_AQI_Sensor_2_Display_String,
                    PM25_AQI_Avg_1_and_2_Display_String, PM_1_dot_0_cf_Sensor_1_Display_String, 
                    PM_2_dot_5_cf_Sensor_1_Display_String,  PM_10_cf_Sensor_1_Display_String, PM_1_dot_0_atm_Sensor_1_Display_String,  
                    PM_2_dot_5_atm_Sensor_1_Display_String, PM_10_atm_Sensor_1_Display_String,  PM_1_dot_0_cf_Sensor_2_Display_String,
                    PM_2_dot_5_cf_Sensor_2_Display_String,  PM_10_cf_Sensor_2_Display_String, PM_1_dot_0_atm_Sensor_2_Display_String,  
                    PM_2_dot_5_atm_Sensor_2_Display_String, PM_10_atm_Sensor_2_Display_String,  Collection_DateTime_Display_String);

            }
            catch (Exception ex)
            {
                CrestronConsole.PrintLine("PurpleAir-Error Obtaining PurpleAir Datapoints");
                CrestronConsole.PrintLine(ex.ToString());
                Crestron.SimplSharp.ErrorLog.Error("PurpleAir-Error Obtaining PurpleAir Datapoints");
                Crestron.SimplSharp.ErrorLog.Error(ex.ToString());
                return;
            }
            #endregion
        }
        //****************************************************************************************
        // 
        //  Send_Message_Get	-	
        // 
        //****************************************************************************************
        private HttpClientResponse Send_Message_Get(string url)
        {

            // Create the client
            HttpClient httpClient = new HttpClient();

            //create the request, populate it
            HttpClientRequest httpRequest = new HttpClientRequest();

            httpRequest.Url.Parse(url);
            httpRequest.RequestType = RequestType.Get;

            //attempt to dispatch the request
            try
            {
                return httpClient.Dispatch(httpRequest);
            }
            catch (Exception ex)
            {
                CrestronConsole.PrintLine("PurpleAir-Error Sending Message (0) url = ", url);
                CrestronConsole.PrintLine(ex.ToString());
                Crestron.SimplSharp.ErrorLog.Error("PurpleAir-Error Sending Message (0) url = ", url);
                Crestron.SimplSharp.ErrorLog.Error(ex.ToString());
                return null;
            }
        }
        //****************************************************************************************
        // 
        //  Parse_Data	-	
        // 
        //****************************************************************************************
        private void Parse_Data(string s)
        {
            string Collection_Date_Time_S, Collection_Date_S, Collection_Time_S;

            //CrestronConsole.PrintLine("PurpleAir data = " + s);

            #region Parse Date/Time
            Collection_Date_Time_S = Parse_Data_Substring(s, "\"DateTime\":\"", "z");
            Collection_Date_Time_S = "D" + Collection_Date_Time_S + "Z";		//Add border characters for parsing routine			
            Collection_Date_S = Parse_Data_Substring(Collection_Date_Time_S, "D", "T");
            Collection_Time_S = Parse_Data_Substring(Collection_Date_Time_S, "T", "Z");
            DateTime d = DateTime.Parse(Collection_Date_S + " " + Collection_Time_S);
            Collection_DateTime_Display_String = d.ToLocalTime().ToString();
            #endregion

            #region Parse data
            Latitude_S = Parse_Data_Substring(s, "\"lat\":", ",");
            Longitude_S = Parse_Data_Substring(s, "\"lon\":", ",");
            Place_S = Parse_Data_Substring(s, "\"place\":", ",");
            Temperature_F_S = Parse_Data_Substring(s, "\"current_temp_f\":", ",");
            Humidity_S = Parse_Data_Substring(s, "\"current_humidity\":", ",");
            Dewpoint_F_S = Parse_Data_Substring(s, "\"current_dewpoint_f\":", ",");
            Pressure_S = Parse_Data_Substring(s, "\"pressure\":", ",");
            PM25_AQI_Sensor_1_S = Parse_Data_Substring(s, "\"pm2.5_aqi\":", ",");
            if (Sensor_Count == 2)
            {
                PM25_AQI_Sensor_2_S = Parse_Data_Substring(s, "\"pm2.5_aqi_b\":", ",");
            }
            else
            {
                PM25_AQI_Sensor_2_S = "";
            }
            PM25_AQI_Color_Sensor_1_S = Parse_Data_Substring(s, "\"p25aqic\":\"", "\"");
            if (Sensor_Count == 2)
            {
                PM25_AQI_Color_Sensor_2_S = Parse_Data_Substring(s, "\"p25aqic_b\":\"", "\"");
            }
            else
            {
                PM25_AQI_Color_Sensor_2_S = "";
            }
            PM_1_dot_0_cf_Sensor_1_S = Parse_Data_Substring(s, "\"pm1_0_cf_1\":", ",");
            PM_2_dot_5_cf_Sensor_1_S = Parse_Data_Substring(s, "\"pm2_5_cf_1\":", ",");
            PM_10_cf_Sensor_1_S = Parse_Data_Substring(s, "\"pm10_0_cf_1\":", ",");
            PM_1_dot_0_atm_Sensor_1_S = Parse_Data_Substring(s, "\"pm1_0_atm\":", ",");
            PM_2_dot_5_atm_Sensor_1_S = Parse_Data_Substring(s, "\"pm2_5_atm\":", ",");
            PM_10_atm_Sensor_1_S = Parse_Data_Substring(s, "\"pm10_0_atm\":", ",");
            if (Sensor_Count == 2)
            {
                PM_1_dot_0_cf_Sensor_2_S = Parse_Data_Substring(s, "\"pm1_0_cf_1_b\":", ",");
                PM_2_dot_5_cf_Sensor_2_S = Parse_Data_Substring(s, "\"pm2_5_cf_1_b\":", ",");
                PM_10_cf_Sensor_2_S = Parse_Data_Substring(s, "\"pm10_0_cf_1_b\":", ",");
                PM_1_dot_0_atm_Sensor_2_S = Parse_Data_Substring(s, "\"pm1_0_atm_b\":", ",");
                PM_2_dot_5_atm_Sensor_2_S = Parse_Data_Substring(s, "\"pm2_5_atm_b\":", ",");
                PM_10_atm_Sensor_2_S = Parse_Data_Substring(s, "\"pm10_0_atm_b\":", ",");
            }
            else
            {
                PM_1_dot_0_cf_Sensor_2_S = "";
                PM_2_dot_5_cf_Sensor_2_S = "";
                PM_10_cf_Sensor_2_S = "";
                PM_1_dot_0_atm_Sensor_2_S = "";
                PM_2_dot_5_atm_Sensor_2_S = "";
                PM_10_atm_Sensor_2_S = "";
            }
            #endregion

            #region Set Data Validity
            Latitude_Valid = Set_Element_Validity(Latitude_S);
            Longitude_Valid = Set_Element_Validity(Longitude_S);
            Place_Valid = Set_Element_Validity(Place_S);
            Temperature_F_Valid = Set_Element_Validity(Temperature_F_S);
            Humidity_Valid = Set_Element_Validity(Humidity_S);
            Dewpoint_F_Valid = Set_Element_Validity(Dewpoint_F_S);
            Pressure_Valid = Set_Element_Validity(Pressure_S);
            PM25_AQI_Sensor_1_Valid = Set_Element_Validity(PM25_AQI_Sensor_1_S);
            if (Sensor_Count == 2)
            {
                PM25_AQI_Sensor_2_Valid = Set_Element_Validity(PM25_AQI_Sensor_2_S);
            }
            else
            {
                PM25_AQI_Sensor_2_Valid = 0;
            }
            PM25_AQI_Color_Sensor_1_Valid = Set_Element_Validity(PM25_AQI_Color_Sensor_1_S);
            if (Sensor_Count == 2)
            {
                PM25_AQI_Color_Sensor_2_Valid = Set_Element_Validity(PM25_AQI_Color_Sensor_2_S);
            }
            else
            {
                PM25_AQI_Color_Sensor_2_Valid = 0;
            }
            PM_1_dot_0_cf_Sensor_1_Valid = Set_Element_Validity(PM_1_dot_0_cf_Sensor_1_S);
            PM_2_dot_5_cf_Sensor_1_Valid = Set_Element_Validity(PM_2_dot_5_cf_Sensor_1_S);
            PM_10_cf_Sensor_1_Valid = Set_Element_Validity(PM_10_cf_Sensor_1_S);
            PM_1_dot_0_atm_Sensor_1_Valid = Set_Element_Validity(PM_1_dot_0_atm_Sensor_1_S);
            PM_2_dot_5_atm_Sensor_1_Valid = Set_Element_Validity(PM_2_dot_5_atm_Sensor_1_S);
            PM_10_atm_Sensor_1_Valid = Set_Element_Validity(PM_10_atm_Sensor_1_S);
            if (Sensor_Count == 2)
            {
                PM_1_dot_0_cf_Sensor_2_Valid = Set_Element_Validity(PM_1_dot_0_cf_Sensor_2_S);
                PM_2_dot_5_cf_Sensor_2_Valid = Set_Element_Validity(PM_2_dot_5_cf_Sensor_2_S);
                PM_10_cf_Sensor_2_Valid = Set_Element_Validity(PM_10_cf_Sensor_2_S);
                PM_1_dot_0_atm_Sensor_2_Valid = Set_Element_Validity(PM_1_dot_0_atm_Sensor_2_S);
                PM_2_dot_5_atm_Sensor_2_Valid = Set_Element_Validity(PM_2_dot_5_atm_Sensor_2_S);
                PM_10_atm_Sensor_2_Valid = Set_Element_Validity(PM_10_atm_Sensor_2_S);
            }
            else
            {
                PM_1_dot_0_cf_Sensor_2_Valid = 0;
                PM_2_dot_5_cf_Sensor_2_Valid = 0;
                PM_10_cf_Sensor_2_Valid = 0;
                PM_1_dot_0_atm_Sensor_2_Valid = 0;
                PM_2_dot_5_atm_Sensor_2_Valid = 0;
                PM_10_atm_Sensor_2_Valid = 0;
            }
            #endregion

            #region Numerical Conversion
            Temperature_F = Parsed_String_To_Short(Temperature_F_Valid, Temperature_F_S, 1);
            Humidity = Parsed_String_To_Short(Humidity_Valid, Humidity_S, 1);
            Dewpoint_F = Parsed_String_To_Short(Dewpoint_F_Valid, Dewpoint_F_S, 1);
            Pressure = Parsed_String_To_Short(Pressure_Valid, Pressure_S, 1);
            PM25_AQI_Sensor_1 = Parsed_String_To_Short(PM25_AQI_Sensor_1_Valid, PM25_AQI_Sensor_1_S, 1);
            if (Sensor_Count == 2)
            {
                PM25_AQI_Sensor_2 = Parsed_String_To_Short(PM25_AQI_Sensor_2_Valid, PM25_AQI_Sensor_2_S, 1);
            }
            else
            {
                PM25_AQI_Sensor_2 = 0;
            }
            #region Calc Average AQI
            if (Sensor_Count == 1)
            {
                PM25_AQI_Avg_1_and_2 = PM25_AQI_Sensor_1;
                PM25_AQI_Avg_1_and_2_Valid = 1;
            }
            else if ((PM25_AQI_Sensor_1_Valid == 1) && (PM25_AQI_Sensor_2_Valid == 1))
            {
                double temp = (Convert.ToDouble(PM25_AQI_Sensor_1) + Convert.ToDouble(PM25_AQI_Sensor_2)) / 2;
                temp = Math.Round(temp, 0);
                PM25_AQI_Avg_1_and_2 = Convert.ToInt16(temp);
                PM25_AQI_Avg_1_and_2_Valid = 1;
            }
            else if ((PM25_AQI_Sensor_1_Valid == 1) && (PM25_AQI_Sensor_2_Valid == 0))
            {
                PM25_AQI_Avg_1_and_2 = PM25_AQI_Sensor_1;
            }
            else if ((PM25_AQI_Sensor_1_Valid == 0) && (PM25_AQI_Sensor_2_Valid == 1))
            {
                PM25_AQI_Avg_1_and_2 = PM25_AQI_Sensor_2;
            }
            else
            {
                PM25_AQI_Avg_1_and_2 = 0;
            }
            #endregion
            Parse_RGB_String(PM25_AQI_Color_Sensor_1_Valid, PM25_AQI_Color_Sensor_1_S, out PM25_Color_RGB_Red_Sensor_1, 
                out PM25_Color_RGB_Green_Sensor_1, out PM25_Color_RGB_Blue_Sensor_1);
            if (Sensor_Count == 2)
            {
                Parse_RGB_String(PM25_AQI_Color_Sensor_2_Valid, PM25_AQI_Color_Sensor_2_S, out PM25_Color_RGB_Red_Sensor_2,
                    out PM25_Color_RGB_Green_Sensor_2, out PM25_Color_RGB_Blue_Sensor_2);
            }
            else
            {
                PM25_Color_RGB_Red_Sensor_2 = 0;
                PM25_Color_RGB_Green_Sensor_2 = 0;
                PM25_Color_RGB_Blue_Sensor_2 = 0;
            }
            PM_1_dot_0_cf_Sensor_1 = Parsed_String_To_Short(PM_1_dot_0_cf_Sensor_1_Valid, PM_1_dot_0_cf_Sensor_1_S, 100);
            PM_2_dot_5_cf_Sensor_1 = Parsed_String_To_Short(PM_2_dot_5_cf_Sensor_1_Valid, PM_2_dot_5_cf_Sensor_1_S, 100);
            PM_10_cf_Sensor_1 = Parsed_String_To_Short(PM_10_cf_Sensor_1_Valid, PM_10_cf_Sensor_1_S, 100);
            PM_1_dot_0_atm_Sensor_1 = Parsed_String_To_Short(PM_1_dot_0_atm_Sensor_1_Valid, PM_1_dot_0_atm_Sensor_1_S, 100);
            PM_2_dot_5_atm_Sensor_1 = Parsed_String_To_Short(PM_2_dot_5_atm_Sensor_1_Valid, PM_2_dot_5_atm_Sensor_1_S, 100);
            PM_10_atm_Sensor_1 = Parsed_String_To_Short(PM_10_atm_Sensor_1_Valid, PM_10_atm_Sensor_1_S, 100);
            if (Sensor_Count == 2)
            {
                PM_1_dot_0_cf_Sensor_2 = Parsed_String_To_Short(PM_1_dot_0_cf_Sensor_2_Valid, PM_1_dot_0_cf_Sensor_2_S, 100);
                PM_2_dot_5_cf_Sensor_2 = Parsed_String_To_Short(PM_2_dot_5_cf_Sensor_2_Valid, PM_2_dot_5_cf_Sensor_2_S, 100);
                PM_10_cf_Sensor_2 = Parsed_String_To_Short(PM_10_cf_Sensor_2_Valid, PM_10_cf_Sensor_2_S, 100);
                PM_1_dot_0_atm_Sensor_2 = Parsed_String_To_Short(PM_1_dot_0_atm_Sensor_2_Valid, PM_1_dot_0_atm_Sensor_2_S, 100);
                PM_2_dot_5_atm_Sensor_2 = Parsed_String_To_Short(PM_2_dot_5_atm_Sensor_2_Valid, PM_2_dot_5_atm_Sensor_2_S, 100);
                PM_10_atm_Sensor_2 = Parsed_String_To_Short(PM_10_atm_Sensor_2_Valid, PM_10_atm_Sensor_2_S, 100);
            }
            else
            {
                PM_1_dot_0_cf_Sensor_2 = 0;
                PM_2_dot_5_cf_Sensor_2 = 0;
                PM_10_cf_Sensor_2 = 0;
                PM_1_dot_0_atm_Sensor_2 = 0;
                PM_2_dot_5_atm_Sensor_2 = 0;
                PM_10_atm_Sensor_2 = 0;
            }
            #endregion

            #region Create Display Strings
            Latitude_Display_String = Create_Display_String_From_String(Latitude_Valid, Latitude_S, "Latitude = ", "");
            Longitude_Display_String = Create_Display_String_From_String(Longitude_Valid, Longitude_S, "Longitude = ", "");
            Place_Display_String = Create_Display_String_From_String(Place_Valid, Place_S, "Place = ", "");
            Temperature_F_Display_String = Create_Display_String_From_Short(Temperature_F_Valid, Temperature_F, "Temperature = ", " F");
            Humidity_Display_String = Create_Display_String_From_Short(Humidity_Valid, Humidity, "Humidity = ", "%");
            Dewpoint_F_Display_String = Create_Display_String_From_Short(Dewpoint_F_Valid, Dewpoint_F, "Dewpoint = ", " F");
            Pressure_Display_String = Create_Display_String_From_Short(Pressure_Valid, Pressure, "Pressure = ", "mb");
            PM25_AQI_Sensor_1_Display_String = Create_AQI_Display_String(PM25_AQI_Sensor_1_Valid, PM25_AQI_Sensor_1, "PM 2.5 AQI (Sensor 1)");
            if (Sensor_Count == 2)
            {
                PM25_AQI_Sensor_2_Display_String = Create_AQI_Display_String(PM25_AQI_Sensor_2_Valid, PM25_AQI_Sensor_2, "PM 2.5 AQI (Sensor 2)");
            }
            else
            {
                PM25_AQI_Sensor_2_Display_String = "";
            }
            PM25_AQI_Avg_1_and_2_Display_String = Create_AQI_Display_String(PM25_AQI_Avg_1_and_2_Valid, PM25_AQI_Sensor_2, "PM 2.5 AQI (Avg)");
            PM_1_dot_0_cf_Sensor_1_Display_String = "PM 1.0 (cf) particle concentration readings from sensor 1 = " + PM_1_dot_0_cf_Sensor_1_S + " ug/m3";
            PM_2_dot_5_cf_Sensor_1_Display_String = "PM 2.5 (cf) particle concentration readings from sensor 1 = " + PM_2_dot_5_cf_Sensor_1_S + " ug/m3";
            PM_10_cf_Sensor_1_Display_String = "PM 10 (cf) particle concentration readings from sensor 1 = " + PM_10_cf_Sensor_1_S + " ug/m3";
            PM_1_dot_0_atm_Sensor_1_Display_String = "PM 1.0 (atm) particle concentration readings from sensor 1 = " + PM_1_dot_0_atm_Sensor_1_S + " ug/m3";
            PM_2_dot_5_atm_Sensor_1_Display_String = "PM 2.5 (atm) particle concentration readings from sensor 1 = " + PM_2_dot_5_atm_Sensor_1_S + " ug/m3";
            PM_10_atm_Sensor_1_Display_String = "PM 10 (atm) particle concentration readings from sensor 1 = " + PM_10_atm_Sensor_1_S + " ug/m3";
            if (Sensor_Count == 2)
            {
                PM_1_dot_0_cf_Sensor_2_Display_String = "PM 1.0 (cf) particle concentration readings from sensor 2 = " + PM_1_dot_0_cf_Sensor_2_S + " ug/m3";
                PM_2_dot_5_cf_Sensor_2_Display_String = "PM 2.5 (cf) particle concentration readings from sensor 2 = " + PM_2_dot_5_cf_Sensor_2_S + " ug/m3";
                PM_10_cf_Sensor_2_Display_String = "PM 10 (cf) particle concentration readings from sensor 2 = " + PM_10_cf_Sensor_2_S + " ug/m3";
                PM_1_dot_0_atm_Sensor_2_Display_String = "PM 1.0 (atm) particle concentration readings from sensor 2 = " + PM_1_dot_0_atm_Sensor_2_S + " ug/m3";
                PM_2_dot_5_atm_Sensor_2_Display_String = "PM 2.5 (atm) particle concentration readings from sensor 2 = " + PM_2_dot_5_atm_Sensor_2_S + " ug/m3";
                PM_10_atm_Sensor_2_Display_String = "PM 10 (atm) particle concentration readings from sensor 2 = " + PM_10_atm_Sensor_2_S + " ug/m3";
            }
            else
            {
                PM_1_dot_0_cf_Sensor_2_Display_String = "";
                PM_2_dot_5_cf_Sensor_2_Display_String = "";
                PM_10_cf_Sensor_2_Display_String = "";
                PM_1_dot_0_atm_Sensor_2_Display_String = "";
                PM_2_dot_5_atm_Sensor_2_Display_String = "";
                PM_10_atm_Sensor_2_Display_String = "";
            }
            #endregion

            #region Print Test Data to Console
            /*
            CrestronConsole.PrintLine("Start Showing Test Data");
            CrestronConsole.PrintLine(Latitude_Display_String);
            CrestronConsole.PrintLine(Longitude_Display_String);
            CrestronConsole.PrintLine(Place_Display_String);
            CrestronConsole.PrintLine(Temperature_F_Display_String);
            CrestronConsole.PrintLine(Humidity_Display_String);
            CrestronConsole.PrintLine(Dewpoint_F_Display_String);
            CrestronConsole.PrintLine(Pressure_Display_String);
            CrestronConsole.PrintLine(PM25_AQI_Sensor_1_Display_String);
            if (Sensor_Count == 2)
            {
                CrestronConsole.PrintLine(PM25_AQI_Sensor_2_Display_String);
            }
            CrestronConsole.PrintLine(PM25_AQI_Avg_1_and_2_Display_String);
            CrestronConsole.PrintLine("PM25_AQI_Color_Sensor_1_S = " + PM25_AQI_Color_Sensor_1_S);
            CrestronConsole.PrintLine("PM2_5_Color_RGB_Red_Sensor_1 = " + PM25_Color_RGB_Red_Sensor_1);
            CrestronConsole.PrintLine("PM2_5_Color_RGB_Green_Sensor_1 = " + PM25_Color_RGB_Green_Sensor_1);
            CrestronConsole.PrintLine("PM2_5_Color_RGB_Blue_Sensor_1 = " + PM25_Color_RGB_Blue_Sensor_1);
            if (Sensor_Count == 2)
            {
                CrestronConsole.PrintLine("PM25_AQI_Color_Sensor_2_S = " + PM25_AQI_Color_Sensor_2_S);
                CrestronConsole.PrintLine("PM2_5_Color_RGB_Red_Sensor_2 = " + PM25_Color_RGB_Red_Sensor_2);
                CrestronConsole.PrintLine("PM2_5_Color_RGB_Green_Sensor_2 = " + PM25_Color_RGB_Green_Sensor_2);
                CrestronConsole.PrintLine("PM2_5_Color_RGB_Blue_Sensor_2 = " + PM25_Color_RGB_Blue_Sensor_2);
            }
            CrestronConsole.PrintLine(PM_1_dot_0_cf_Sensor_1_Display_String);
            CrestronConsole.PrintLine(PM_2_dot_5_cf_Sensor_1_Display_String);
            CrestronConsole.PrintLine(PM_10_cf_Sensor_1_Display_String);
            CrestronConsole.PrintLine(PM_1_dot_0_atm_Sensor_1_Display_String);
            CrestronConsole.PrintLine(PM_2_dot_5_atm_Sensor_1_Display_String);
            CrestronConsole.PrintLine(PM_10_atm_Sensor_1_Display_String);
            if (Sensor_Count == 2)
            {
            CrestronConsole.PrintLine(PM_1_dot_0_cf_Sensor_2_Display_String);
            CrestronConsole.PrintLine(PM_2_dot_5_cf_Sensor_2_Display_String);
            CrestronConsole.PrintLine(PM_10_cf_Sensor_2_Display_String);
            CrestronConsole.PrintLine(PM_1_dot_0_atm_Sensor_2_Display_String);
            CrestronConsole.PrintLine(PM_2_dot_5_atm_Sensor_2_Display_String);
            CrestronConsole.PrintLine(PM_10_atm_Sensor_2_Display_String);
            }
            CrestronConsole.PrintLine("Finish Showing Test Data");
            */
            #endregion
        }
        //****************************************************************************************
        // 
        //  Parse_Data_Substring	-	Parse Data Element from Json
        // 
        //****************************************************************************************
        private string Parse_Data_Substring(string s, string id, string ending_char)
        {
            int index1, index2;

            //get index to start of value
            index1 = s.IndexOf(id, 0);
            if (index1 == -1)
            {
                CrestronConsole.PrintLine("PurpleAir-Unable to Locate " + id + " in " + s);
                Crestron.SimplSharp.ErrorLog.Error("PurpleAir-Unable to Locate " + id + " in " + s);
                return "";
            }
            else
            {
                index1 += id.Length;
            }

            //get index to end of value
            index2 = s.IndexOf(ending_char, (index1 + 1));
            if (index2 == -1)
            {
                CrestronConsole.PrintLine("PurpleAir-Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
                Crestron.SimplSharp.ErrorLog.Error("PurpleAir-Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
                return "";
            }

            //get value substring and pass it back
            return s.Substring(index1, index2 - index1);
        }
        //****************************************************************************************
        // 
        //  Set_Element_Validity	-	
        // 
        //****************************************************************************************
        private short Set_Element_Validity(string s)
        {
            if (s == "")
            {
                return 0;
            }
            else
            {
                return 1;
            }
        }
        //****************************************************************************************
        // 
        //  Parsed_String_To_Short	-	
        // 
        //****************************************************************************************
        private short Parsed_String_To_Short(short Valid, string s, double scale)
        {
            if (Valid == 1)
            {
                double temp = Convert.ToDouble(s) * scale;
                temp = Math.Round(temp, 0);
                return Convert.ToInt16(temp);
            }
            else
            {
                return 0;
            }
        }
        //****************************************************************************************
        // 
        //  Parse_RGB_String	-	
        // 
        //****************************************************************************************
        private void Parse_RGB_String(short Valid, string RGB_String, out short Red, out short Green, out short Blue)
        {
            bool ret_val;
            int next_start_index;

            if (Valid == 1)
            {
                ret_val = Parse_RGB_Color(RGB_String, "(", ",", 0, out Red, out next_start_index);
                if (ret_val == true)
                {
                    ret_val = Parse_RGB_Color(RGB_String, ",", ",", next_start_index, out Green, out next_start_index);
                    if (ret_val == true)
                    {
                        ret_val = Parse_RGB_Color(RGB_String, ",", ")", next_start_index, out Blue, out next_start_index);
                        if (ret_val == false)
                        {
                            Red = 0;
                            Green = 0;
                            Blue = 0;
                        }
                    }
                    else
                    {
                        Red = 0;
                        Green = 0;
                        Blue = 0;
                    }
                }
                else
                {
                    Red = 0;
                    Green = 0;
                    Blue = 0;
                }
            }
            else
            {
                Red = 0;
                Green = 0;
                Blue = 0;
            }
        }
        //****************************************************************************************
        // 
        //  Parsed_RGB_Color	-	
        // 
        //****************************************************************************************
        private bool Parse_RGB_Color(string s, string id, string ending_char, int start_index, out short color, out int next_start_index)
        {
            int index1, index2;

            //Parse Red Value
            //get index to start of value
            index1 = s.IndexOf(id, start_index);
            if (index1 == -1)
            {
                CrestronConsole.PrintLine("PurpleAir-Unable to Locate " + id + " in " + s);
                Crestron.SimplSharp.ErrorLog.Error("PurpleAir-Unable to Locate " + id + " in " + s);
                color = 0;
                next_start_index = 0;
                return false;
            }
            else
            {
                index1 += id.Length;
            }

            //get index to end of value
            index2 = s.IndexOf(ending_char, (index1 + 1));
            if (index2 == -1)
            {
                CrestronConsole.PrintLine("PurpleAir-Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
                Crestron.SimplSharp.ErrorLog.Error("PurpleAir-Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
                color = 0;
                next_start_index = 0; 
                return false;
            }

            //get value substring and pass it back
            color = Convert.ToInt16(s.Substring(index1, index2 - index1));
            next_start_index = index2;
            return true;
        }
        //****************************************************************************************
        // 
        //  Create_AQI_Display_String	-	
        // 
        //****************************************************************************************
        string Create_AQI_Display_String(short AQI_Valid, short AQI, string Prefix)
        {
            if ((AQI >= 0) && (AQI <= 50))
            {
                return Create_Display_String_From_Short(AQI_Valid, AQI, Prefix + " = ", " - Good"); ;
            }
            else if ((AQI >= 51) && (AQI <= 100))
            {
                return Create_Display_String_From_Short(AQI_Valid, AQI, Prefix + " = ", " - Moderate"); ;
            }
            else if ((AQI >= 101) && (AQI <= 150))
            {
                return Create_Display_String_From_Short(AQI_Valid, AQI, Prefix + " = ", " - Unhealthy for Sensitive Groups"); ;
            }
            else if ((AQI >= 151) && (AQI <= 200))
            {
                return Create_Display_String_From_Short(AQI_Valid, AQI, Prefix + " = ", " - Unhealthy"); ;
            }
            else if ((AQI >= 201) && (AQI <= 300))
            {
                return Create_Display_String_From_Short(AQI_Valid, AQI, Prefix + " = ", " - Very Unhealthy"); ;
            }
            else if (AQI >= 301)
            {
                return Create_Display_String_From_Short(AQI_Valid, AQI, Prefix + " = ", " - Hazardous"); ;
            }
            else
            {
                return "";
            }

        }
        //****************************************************************************************
        // 
        //  Create_Display_String_From_Short	-	
        // 
        //****************************************************************************************
        private string Create_Display_String_From_Short(short Valid, short data, string beginning, string end)
        {
            if (Valid == 0)
            {
                return "";
            }
            else
            {
                return beginning + data.ToString() + end;
            }
        }
        //****************************************************************************************
        // 
        //  Create_Display_String_From_String	-	
        // 
        //****************************************************************************************
        private string Create_Display_String_From_String(short Valid, string data, string beginning, string end)
        {
            if (Valid == 0)
            {
                return "";
            }
            else
            {
                return beginning + data + end;
            }
        }
    }
}
