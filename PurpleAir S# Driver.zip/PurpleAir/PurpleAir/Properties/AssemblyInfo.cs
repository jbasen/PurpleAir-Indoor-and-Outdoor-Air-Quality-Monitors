﻿using System.Reflection;

[assembly: AssemblyTitle("PurpleAir")]
[assembly: AssemblyCompany("HP Inc.")]
[assembly: AssemblyProduct("PurpleAir")]
[assembly: AssemblyCopyright("Copyright © HP Inc. 2020")]
[assembly: AssemblyVersion("1.0.0.*")]

